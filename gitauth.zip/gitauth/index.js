const express = require("express");
const axios = require("axios");
var cors = require("cors");

const CLIENT_ID = "2ae2156246dd2cd9dc62";
const CLIENT_SECRET = "3017244985984831c7c95350452c914c1616d08a";
const GITHUB_URL = "https://github.com/login/oauth/access_token";

const app = express();
app.use(cors({ credentials: true, origin: true }));



app.get("/",async (req,res)=>{
  let result = await axios.get("https://github.com/login/oauth/authorize",{
    params:{
        client_id:CLIENT_ID,
        redirect_uri:"/oauth/redirect",
    }
  })
  res.end(result.data);

})

app.get("/oauth/redirect", (req, res) => {
  axios({
    method: "POST",
    url: `${GITHUB_URL}?client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}&code=${req.query.code}`,
    headers: {
      Accept: "application/json",
    },
  }).then((response) => {
    res.redirect(
      `http://localhost:8080/index?access_token=${response.data.access_token}`
    );
  }).catch(e=>{
    res.statusCode=500;
    res.end(e);
  })
});

app.get("/index", (req, res)=>{
   res.json(req.query);
});

const PORT = 8080;
app.listen(PORT, () => {
  console.log(`Listening at port ${PORT}`);
});
