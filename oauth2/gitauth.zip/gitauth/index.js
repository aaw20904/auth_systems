const express = require("express");
const axios = require("axios");
var cors = require("cors");
const ejs = require("ejs");
const cookieParser = require("cookie-parser");
/* https://stateful.com/blog/github-oauth - the example */
// https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-the-authenticated-user

const CLIENT_ID = "2ae2156246dd2cd9dc62";
const CLIENT_SECRET = "3017244985984831c7c95350452c914c1616d08a";
const GITHUB_URL = "https://github.com/login/oauth/access_token";
const querystring = require('node:querystring');

const loginParams =  querystring.stringify({
                            client_id:CLIENT_ID,
                             redirect_uri:"http://localhost:8080/callback",
                            scope: ['read:user', 'user:email'].join(' '),  
                            allow_signup: true, 
                      })

const app = express();
app.use(cors({ credentials: true, origin: true }));
app.use(express.urlencoded({extended:false}));
app.use(cookieParser())
app.set("view engine","ejs");


async function dataMiddleware(req, res, next){
  if (req.cookies.git_token) {
      let userInfo = await axios.get("https://api.github.com/user", {
        headers: {
          Authorization: `Bearer ${req.cookies.git_token}`,
          Accept: "application/vnd.github+json",
          "X-GitHub-Api-Version": "2022-11-28"
        }
      });

      ///name company location avatar_url
      res.json(userInfo.data);
      return;
      //next();
  }else {
    req.usrData = false;
    next();
  }
}

app.get("/", async (req,res)=>{

  // 1)start page
  res.render("index",{date:  new Date().toString()});

});

app.get("/auth", (req, res)=>{
   //2) Create a http request to gitub for authentication-
   
  res.redirect(`https://github.com/login/oauth/authorize?${loginParams}`)
  //3)the github rturned the token to the redirect URI ( "/callback")
})


app.get("/callback", async (req,res)=>{
   //4) Github sending  the token as URI parameter   
    const code =  req.query.code;
   
   let tokens;
   try{
    /// 5) making the request to GITHUB - require the access_token
      tokens = await axios.post("https://github.com/login/oauth/access_token",
          {
              client_id: CLIENT_ID,
              client_secret: CLIENT_SECRET,
              code: code,
            /*  !! you MUSN'T include "redirect_uri" here !!!  */       
          },
          {
              headers: {
                  Accept: "application/json"
              }
          }
      )
   }catch(e){
    res.statusCode=500;
    res.end("server error");
   }
   /*6) assign the token to cookie (or save in DB). 
   There are three props in tokens.data: .access_token, .token_type, .scope
    */
    if(!tokens.data.access_token) {
      res.redirect("/");
      return;
    }
    res.cookie("git_token", tokens.data.access_token,{maxAge:60000*10});
  res.redirect("/index");
})



app.get("/index", dataMiddleware, (req, res)=>{
   res.json(req.query);
});

const PORT = 8080;
app.listen(PORT, () => {
  console.log(`Listening at port ${PORT}`);
});
