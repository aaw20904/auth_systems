const crypto = require("crypto")
class MyJWTlib{
    #base64;
    #restoreFrom64;

    constructor(){
        this.#base64=(data)=>{
            return Buffer.from(data).toString('base64')
                          .replace(/=/g, '')
                          .replace(/\+/g, '-')
                          .replace(/\//g, '_');
        }

        this.#restoreFrom64 = (b64)=>{
            let prep = b64.replace(/''/g,'=')
                .replace(/\-/g, '+')
                .replace(/\_/g, '/');
                return Buffer.from(prep,"base64")
        }
    }

  

    encodeUnsigned(header, payload) {
        let decodedHeader = this.#base64(JSON.stringify(header));
        let decodedPayload = this.#base64(JSON.stringify(payload));
        return `${decodedHeader}.${decodedPayload}`;
    }

    decodeUnsigned(token) {
        const [headerB64, payloadB64] = token.split('.');
        // These supports parsing the URL safe variant of Base64 as well.
        const headerStr = Buffer.from(headerB64, 'base64').toString();
        const payloadStr =  Buffer.from(payloadB64, 'base64').toString();
        return {
            header: JSON.parse(headerStr),
            payload: JSON.parse(payloadStr)
        };
    }

    async signAsymmetrically(payload, key, algorythm) {
        let header = {
            type:"jwt",
            alg:"RS256"
        }
        let mystring = '10/2=5;2+2=4;10-1=9';
        let tm = this.#base64(mystring);
        let rs = this.#restoreFrom64(tm).toString();
        let encodedHeader = this.#base64(JSON.stringify(header));
        let encodedPayload = this.#base64(JSON.stringify(payload));
        let sig = await new Promise((resolve, reject) => {
            crypto.sign(algorythm, Buffer.from(`${encodedHeader}.${encodedPayload}`) ,key, (err, signature)=>{
                if (err){reject(err)}
                else {
                    resolve(signature);
                }
            });

        });
        let encodedSign = this.#base64(sig);
        return `${encodedHeader}.${encodedPayload}.${encodedSign}`
    }

    async verifyAsymmetrically(token, publickey, alg){
       const [headerB64, payloadB64, signatureB64] = token.split('.');
       let header = JSON.parse(this.#restoreFrom64(headerB64).toString())
       let payload =  JSON.parse(this.#restoreFrom64(headerB64).toString())
       let sign = this.#restoreFrom64(signatureB64);
       let result
       try{
        result= await new Promise((resolve, reject) => {
            crypto.verify(alg, `${headerB64}.${payloadB64}`, publickey, sign,(err, result)=>{
                if (err) {
                    reject(err)
                } else {
                    resolve(result);
                }
            });
 
       });
      } catch(e){
        return false;
      }

       return {header,payload, isValid:result }

       
    }
}

module.exports={MyJWTlib}