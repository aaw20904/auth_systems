const express = require('express');
const router = express.Router();
const bcrypt = require("bcrypt")




router.post("/newuser",async (req, res)=>{
    console.log(req.body);
    let user_id;
    //user_name, user_password
    let hashedPassword = await bcrypt.hash(req.body.user_password, 10);
    try {
     user_id =  await router.dbLayer.addNewUser(req.body.user_name, hashedPassword);
    } catch (e) {
      if (e.userExists) {
        res.status(409);
        res.json({error:"exists"});
      }
      return;
    }
    //returns user_id
    res.json({user_id});

    // Load hash from your password DB.
   //let reverse = await  bcrypt.compare(req.body.user_password, hashedPassword);
   
    
})

module.exports = router
