const express = require('express');
const router = express.Router();
const bcrypt = require("bcrypt");
const jsonwebtoken = require("jsonwebtoken");
const fs = require("fs");
const crypto = require("crypto")
const jose = require("jose")
const myLib = require("../jwt_lib");
const myLibClass = new myLib.MyJWTlib();






router.post("/newtoken", async (req, res)=>{
 //is a token exists?
 if(!req.body.token){
    res.status(499).end();
    return;
 }
 //a) Is a token  valid?
 let decodedRefreshToken;
 let receivedRefreshToken = req.body.token;
 
    try{
        decodedRefreshToken = await jose.jwtVerify(receivedRefreshToken, router.secrets.publicJoseKey )
      //  res.status(200).json({result, expiration_result: new Date(result.exp*1000).toString()});

    }catch(e){
        //when a token isn`t valid - revoke 
        res.status(498).json({error:e});
    }
//1.10) Has a token expired?
     
     if(decodedRefreshToken.payload.exp < ((Date.now()/1000)|0)){
        res.statusCode(498).json("NOT_VAL");
        return;
     }
//2) Is a received token equals to the old?
    //get user info
    let userInfo = await router.dbLayer.getUserById( decodedRefreshToken.payload.user_id); 
    if(!userInfo){
        //when not found
        res.status(404).json({error:"empty"});
        return;
    }
    //compare an old and a received tokens
    let receivedBuffer =  Buffer.from(receivedRefreshToken);
    if(receivedBuffer.length !== userInfo.refresh_token.length){
         res.status(498).end();
        return;
    }
    if( crypto.timingSafeEqual(userInfo.refresh_token, receivedBuffer) ) {
        //reuse occured - token must been revoked
        res.status(409).json({error:"reuse"});
        return;
    }
//3) generate refresh token -----DEBUG here: >>>>>

    let newRefreshToken, newAccessToken;
    try {

        newRefreshToken =   await new jose.SignJWT({ user_id:4 })
                                        .setProtectedHeader({ alg:"RS256" })
                                        .setIssuedAt()
                                        .setIssuer('goooogle')
                                        .setAudience()
                                        .setExpirationTime("5m") // one hour
                                        .sign(router.secrets.privateJoseKey)
       //4) new access token
         newAccessToken =  myLibClass.encodeAccessToken(4, 60000*10, router.secrets.user_key);

    } catch(e){
        ///when token isn`t valid - revoke refresh
        res.status(500).json({err:e});
    }
    //5) save received token 
    await router.dbLayer.writeRefreshToken(userInfo.user_id, receivedRefreshToken);
    //6) respond to the client with new tokens:
    res.status(200).json({access_token:newAccessToken.toString('base64'), refresh_token:newRefreshToken}); 

})


/****test routes   -  only for debugging */

router.post("/test", async (req, res, next)=>{
 let token = myLibClass.encodeAccessToken(4, 60000*10, router.secrets.privkey)
 let decoded = myLibClass.decodeAccessToken(token, router.secrets.pubkey)
 res.json({iss:decoded.iss.toString() , exp:decoded.exp.toString()  , id: decoded.user_id})
})

router.post("/jose",async(req, res)=>{
    var hrstart = process.hrtime();
  const jwt = await new jose.SignJWT({ user_id:4 }).setProtectedHeader({ alg:"RS256" })
                .setIssuedAt()
                .setIssuer('goooogle')
                .setAudience()
                .setExpirationTime('1h')
                .sign(router.secrets.privateJoseKey)
   hrend = process.hrtime(hrstart);
   await router.dbLayer.writeRefreshToken(4, jwt)
  res.json({jwt, execMicrosec: (hrend[1] / 1000)});
})

router.post("/mylib", async (req, res, next)=>{
   
    let decoded=0;
    if (req.body.jwt) {
        decoded = myLibClass.decode(req.body.jwt);
    } 
    var hrstart = process.hrtime();
    const token = newRefreshToken =   await new jose.SignJWT({ user_id:4 })
                                        .setProtectedHeader({ alg:"RS256" })
                                        .setIssuedAt()
                                        .setIssuer('goooogle')
                                        .setAudience()
                                        .setExpirationTime("5m") // one hour
                                        .sign(router.secrets.privateJoseKey) 
    
    //await myLibClass.createAsymSign({user_id:4,exp: ((Date.now()/1000) + 1000)|0},router.secrets.privkey,"RS256");
    hrend = process.hrtime(hrstart);
    res.status(200).json({token: token,  execMicrosec: (hrend[1] / 1000)});
   

})


module.exports=router