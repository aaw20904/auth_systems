/****My own implementation of JWT ***/
const { rejects } = require("assert");
const crypto = require("crypto");
const { resolve } = require("path");

class signLess {
    #b64;
    constructor(){
        ///// URL-safe variant of Base64
        this.#b64=(text)=>{
             return   Buffer.from(text).toString('base64')
                          .replace(/=/g, '')
                          .replace(/\+/g, '-')
                          .replace(/\//g, '_');
        }
    }
   ///encode header nd payload to JWT format
    encode (header, payload) {
           const headerEnc = this.#b64(JSON.stringify(header));                    
            const payloadEnc = this.#b64(JSON.stringify(payload));
            return `${headerEnc}.${payloadEnc}`;
    }

    decode (jwt) {
        const [headerB64, payloadB64] = jwt.split('.');
        // These supports parsing the URL safe variant of Base64 as well.
        const headerStr = Buffer.from(headerB64, 'base64').toString();
        const payloadStr = Buffer.from(payloadB64, 'base64').toString();
        return {
            header: JSON.parse(headerStr),
            payload: JSON.parse(payloadStr)
        };
    }

    async createAsymSign(payload, key, alg) {

        let header= { 
            alg: alg
        }

        let encodedHeader = this.#b64(JSON.stringify(header));
        let encodedPayload = this.#b64(JSON.stringify(payload));
        

       let signature= await new Promise((resolve, reject) => {
                            crypto.sign("SHA256",Buffer.from( `${encodedHeader}.${encodedPayload}`), key, (err, signature)=>{
                            if(err){
                                rejects(err);
                            } else {
                                resolve(signature);
                            }
                        })
                    });
      let encodedSignature = this.#b64(signature);
       
        return `${encodedHeader}.${encodedPayload}.${encodedSignature}`



    }
  


}




module.exports={signLess}