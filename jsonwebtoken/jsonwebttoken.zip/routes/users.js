var express = require('express');
var router = express.Router();
const db = require('../db.js');
const jwt = require('jsonwebtoken');
require('dotenv').config()

const cryptography  = require('../cryptography');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.get('/login', function(req, res, next) {
  
  res.render('login',{msg:'', name_:''})
  return;
});

router.post('/login', async function(req, res, next){
  let token;
  let userinfo = await db.readUserInfo(req.body.name);
  //is a user exists?
  if (!userinfo) {
    res.render('login',{msg:'Incorrect user name or password!',name_:''});
    return;
  } else if(await cryptography.validatePassword(userinfo.userpass.toString('utf8'), req.body.password.toString('utf8'))) {
    //when a password valid - generate jWT;
    token = await new Promise((resolve, reject) => {
          jwt.sign({name: userinfo.username, ident: userinfo.userid},process.env.SECRET_KEY,
                          {algorithm:"HS256", expiresIn:1200 },(err, token)=>{
                            if (err) {
                              reject(err);
                            } else {
                              resolve(token)
                            }
                          })
    });
    //---set JWT:
    res.cookie('jwt', token, {maxAge: (1000 * 3600)|0});
    res.redirect('/');
    return;
  } else {
    res.render('login',{msg:'Incorrect user name or password!', name_:req.body.name});
  }

})


router.get('/register', async (req, res, next)=>{
  res.clearCookie('jwt');
  res.render('register',{msg:''});
})

router.post('/register',async (req, res, next)=>{
  let hashed = await cryptography.hashPassword(req.body.password);

  if( ! await db.addNewUser(req.body.name, hashed)) {
     res.render('register',{msg:'User exists!'});
  } else {

    res.redirect('/');
  }
})

router.post('/logout',(req, res, next)=>{
  res.clearCookie('jwt');
  res.redirect('/users/login');
})

module.exports = router;
