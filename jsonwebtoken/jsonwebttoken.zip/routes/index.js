var express = require('express');
var router = express.Router();







//router.use(jwtValidator);
/* GET home page. */
router.get('/', function(req, res, next) {
  if(! req.userPersonalInfo){
    res.redirect('/users/login');
  } else {
      res.render('index', { title: 'Express', usr: req.userPersonalInfo.name });
  }

});

module.exports = router;
